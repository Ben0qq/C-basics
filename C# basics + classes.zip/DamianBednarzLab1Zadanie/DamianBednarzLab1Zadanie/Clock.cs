﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamianBednarzLab1Zadanie
{
    public class Clock : Counter
    {
        private int season;
        /// <summary>
        /// getter, gets actuall counted time
        /// </summary>
        /// <returns></returns>
        public override int GetCounter()
        {
            return counter;
        }
        /// <summary>
        /// setter, sets current time
        /// </summary>
        /// <param name="counter"></param>
        public override void SetCounter(int counter)
        {
            this.counter = counter;
        }
        /// <summary>
        /// getter, gets current year season
        /// </summary>
        /// <returns></returns>
        public int GetSeason()
        {
            return season;
        }
        /// <summary>
        /// setter, sets current year season
        /// </summary>
        /// <param name="season"></param>
        public void SetSeason(int season)
        {
            this.season = season;
        }
        /// <summary>
        /// function which changes season depending on the previous one (spring->summer->fall->winter)
        /// </summary>
        /// <returns></returns>
        public bool ChangeSeason()
        {
            if (counter % 120 == 0)
            {
                if (season == 0) //change of season part
                {
                    season = 1;
                    return true;
                }
                else if (season == 1)
                {
                    season = 2;
                    return true;
                }
                else if (season == 2)
                {
                    season = 3;
                    return true;
                }
                else if (season == 3)
                {
                    season = 0;
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// time flow function
        /// </summary>
        public void Increment()
        {
            counter++;
        }
    }
}
