﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamianBednarzLab1Zadanie
{
    class Potato : Counter, Vegetable
    {
        /// <summary>
        /// getter, gets number of potatoes player has
        /// </summary>
        /// <returns></returns>
        public override int GetCounter()
        {
            return counter;
        }
        /// <summary>
        /// vegetable grow, depends on number of farmers and blessing event
        /// </summary>
        /// <param name="farmer"></param>
        /// <param name="blessing"></param>
        public void Grow(Farmer farmer, Blessing blessing)
        {
            if (blessing.GetBlessingTime() > 0)
            {
                counter += 2 * farmer.GetCounter();
            }
            else
            {
                counter += farmer.GetCounter();
            }
        }
        /// <summary>
        /// function checks if its enough to feed farmers in current season
        /// </summary>
        /// <param name="farmer"></param>
        /// <returns></returns>
        public bool isEnough(Farmer farmer)
        {
            if (counter > farmer.GetCounter() * farmer.GetFarmerPrice())
                return true;
            else
                return false;
        }
        /// <summary>
        /// setter, sets number of potatoes
        /// </summary>
        /// <param name="counter"></param>
        public override void SetCounter(int counter)
        {
            this.counter = counter;
        }
    }
}
