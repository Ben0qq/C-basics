﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamianBednarzLab1Zadanie
{
    public abstract class Event
    {
        protected Random rnd = new Random();//random number generator
        protected int timeLeft;//time left till event happens
        /// <summary>
        /// getter of timeLeft
        /// </summary>
        /// <returns></returns>
        public abstract int GetTimeLeft();
        /// <summary>
        /// setter of timeLeft
        /// </summary>
        /// <param name="time"></param>
        public abstract void SetTimeLeft(int time);
        /// <summary>
        /// decreases time till event happens
        /// </summary>
        public abstract void Decrement();
    }
}
