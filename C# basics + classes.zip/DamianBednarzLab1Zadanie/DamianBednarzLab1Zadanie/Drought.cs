﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DamianBednarzLab1Zadanie
{
    class Drought : Event
    {
        /// <summary>
        /// contructor, sets the time of first drought (in second year)
        /// </summary>
        public Drought()
        {
            timeLeft = rnd.Next(360) + 480;
        }
        /// <summary>
        /// decreases time till event
        /// </summary>
        public override void Decrement()
        {
            timeLeft--;
        }
        /// <summary>
        /// function called when the event is happening, decreases all resources by half
        /// </summary>
        /// <param name="clock"></param>
        /// <param name="potato"></param>
        /// <param name="tomato"></param>
        /// <param name="pumpkin"></param>
        public void EventHappen(Clock clock, Potato potato, Tomato tomato, Pumpkin pumpkin)
        {
            if ((timeLeft == 0) && (clock.GetSeason() != 3))
            {
                potato.SetCounter( potato.GetCounter()/ 2);
                tomato.SetCounter(tomato.GetCounter() / 2);
                pumpkin.SetCounter(pumpkin.GetCounter() / 2);
                timeLeft = rnd.Next(360) + 140;
                MessageBox.Show("Plaga niszczy połowę zbiorów");
            }
            else if (timeLeft == 0)
            {
                timeLeft = rnd.Next(360) + 140;
            }
        }
        /// <summary>
        /// getter, gets time till event
        /// </summary>
        /// <returns></returns>
        public override int GetTimeLeft()
        {
            return timeLeft;
        }
        /// <summary>
        /// setter, sets time till event
        /// </summary>
        /// <param name="time"></param>
        public override void SetTimeLeft(int time)
        {
            this.timeLeft = time;
        }
    }
}
