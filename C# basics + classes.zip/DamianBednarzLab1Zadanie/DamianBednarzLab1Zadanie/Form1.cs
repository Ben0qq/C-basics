﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Collections.Generic;

namespace DamianBednarzLab1Zadanie
{
    public partial class FormMain : Form
    {
        private Potato potato = new Potato();
        private Tomato tomato = new Tomato();
        private Pumpkin pumpkin = new Pumpkin();
        private Farmer farmer = new Farmer();
        private Clock clock = new Clock();
        private Drought drought = new Drought();
        private Blessing blessing = new Blessing();
        private Newcomer newcomer = new Newcomer();
        private List<string> names = new List<string>(); // list of farmers' names
        private int farmerCounter = 2;
        private Random rnd = new Random();
        private int listIndex;
        /// <summary>
        /// changes timer to 100ms
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonTickRateUp_Click(object sender, EventArgs e)
        {
            timerMain.Interval = 100;
        }
        /// <summary>
        /// changes timer to 1s
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonTickrateDown_Click(object sender, EventArgs e)
        {
            timerMain.Interval = 1000;
        }
        /// <summary>
        /// function which checks condition for buying farmer, and then buys him, also gives them random names
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonFarmer_Click(object sender, EventArgs e)
        {
            bool buyingCompleted;
            farmerCounter++;
            buyingCompleted = farmer.Buy(potato,tomato,pumpkin,clock);
            if (buyingCompleted == true)
            {
                int nameNumber;
                nameNumber = rnd.Next(9);
                string name = "I am error";
                if (nameNumber == 0)
                {
                    name = "Janusz";
                }
                else if (nameNumber == 1)
                {
                    name = "Jonasz";
                }
                else if (nameNumber == 2)
                {
                    name = "Maciek";
                }
                else if (nameNumber == 3)
                {
                    name = "Hubert";
                }
                else if (nameNumber == 4)
                {
                    name = "Gustaw";
                }
                else if (nameNumber == 5)
                {
                    name = "Maurycy";
                }
                else if (nameNumber == 6)
                {
                    name = "Eugeniusz";
                }
                else if (nameNumber == 7)
                {
                    name = "Ambroży";
                }
                else if (nameNumber == 8)
                {
                    name = "Konstanty";
                }
                else if (nameNumber == 9)
                {
                    name = "Jonasz";
                }
                names.Add(name);
            }
        }
        /// <summary>
        /// function creating main window and generating first time of random events spawning
        /// </summary>
        public FormMain()
        {
            listIndex = 0;
            names.Add("Stefan");
            names.Add("Marian");
            InitializeComponent();
        }
        /// <summary>
        /// function which is called with every timer tick, contains most contents of the program
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timerMain_Tick(object sender, EventArgs e)
        {
            
            if (blessing.GetBlessingTime() > 0)
            {
                blessing.SetBlessingTime(blessing.GetBlessingTime()-1);
            }
            clock.Increment();
            if(clock.GetSeason()==0)//here starts part in which the resources are increased
            {
                potato.Grow(farmer,blessing);
                if (potato.isEnough(farmer)==true)
                    textBoxSurvive.Text = "Tak";
                else
                    textBoxSurvive.Text = "Nie";
            }
            else if (clock.GetSeason() == 1)
            {
                tomato.Grow(farmer, blessing);
                if (tomato.isEnough(farmer) == true)
                    textBoxSurvive.Text = "Tak";
                else
                    textBoxSurvive.Text = "Nie";
            }
            else if (clock.GetSeason() == 2)
            {
                pumpkin.Grow(farmer, blessing);
                if (pumpkin.isEnough(farmer) == true)
                    textBoxSurvive.Text = "Tak";
                else
                    textBoxSurvive.Text = "Nie";
            }
            drought.EventHappen(clock,potato,tomato,pumpkin);
            blessing.EventHappen(clock);
            bool eventHappened = newcomer.EventHappen(clock, farmer);
            if(eventHappened == true)
            {
                int nameNumber;
                nameNumber = rnd.Next(9);
                string name = "I am error";
                if (nameNumber == 0)
                {
                    name = "Janusz";
                }
                else if (nameNumber == 1)
                {
                    name = "Jonasz";
                }
                else if (nameNumber == 2)
                {
                    name = "Maciek";
                }
                else if (nameNumber == 3)
                {
                    name = "Hubert";
                }
                else if (nameNumber == 4)
                {
                    name = "Gustaw";
                }
                else if (nameNumber == 5)
                {
                    name = "Maurycy";
                }
                else if (nameNumber == 6)
                {
                    name = "Eugeniusz";
                }
                else if (nameNumber == 7)
                {
                    name = "Ambroży";
                }
                else if (nameNumber == 8)
                {
                    name = "Konstanty";
                }
                else if (nameNumber == 9)
                {
                    name = "Jonasz";
                }
                names.Add(name);
            }
            if(clock.ChangeSeason()==true)
                if (clock.GetSeason() == 1) //change of season part
                {
                    if (potato.isEnough(farmer) == false)
                    {
                        MessageBox.Show("Przegrałeś! Nie wyżywłeś ludzi");
                        this.Close();
                    }
                    potato.SetCounter(potato.GetCounter()-farmer.GetCounter()*farmer.GetFarmerPrice());
                }
                else if (clock.GetSeason() == 2) //change of season part
                {
                    if (tomato.isEnough(farmer) == false)
                    {
                        MessageBox.Show("Przegrałeś! Nie wyżywłeś ludzi");
                        this.Close();
                    }
                }
                else if (clock.GetSeason() == 3)
                {
                    if (pumpkin.isEnough(farmer) == false)
                    {
                        MessageBox.Show("Przegrałeś! Nie wyżywłeś ludzi");
                        this.Close();
                    }
                    int foodAmount = farmer.GetCounter() * farmer.GetFarmerPrice();
                    pumpkin.SetCounter(pumpkin.GetCounter() - farmer.GetCounter() * farmer.GetFarmerPrice());
                    if (foodAmount> pumpkin.GetCounter()+tomato.GetCounter()+potato.GetCounter())
                    {
                        MessageBox.Show("Przegrałeś! Nie wyżywisz ludzi w zimie");
                        this.Close();
                    }
                }
                else if (clock.GetSeason() == 0)
                {
                    int foodAmount = farmer.GetCounter() * farmer.GetFarmerPrice();
                    if (pumpkin.GetCounter() < foodAmount)//in here the program counts the resources needed for winter and takes them from our own
                    {
                        foodAmount -= pumpkin.GetCounter();
                        pumpkin.SetCounter(0);
                    }
                    else
                        pumpkin.SetCounter(pumpkin.GetCounter()-foodAmount);
                    if (tomato.GetCounter() < foodAmount)
                    {
                        foodAmount -= tomato.GetCounter();
                        tomato.SetCounter(0);
                    }
                    else
                        tomato.SetCounter(tomato.GetCounter() - foodAmount);
                    if (potato.GetCounter() < foodAmount)
                    {
                        foodAmount -= potato.GetCounter();
                        potato.SetCounter(0);
                    }
                    else
                        potato.SetCounter(potato.GetCounter() - foodAmount);
                }
            farmer.EndYear(clock);
            textBoxPotato.Text = potato.GetCounter().ToString(); //here begins part in which text boxes update
            textBoxPotatoDrought.Text = (potato.GetCounter() / 2).ToString();
            textBoxTomato.Text = tomato.GetCounter().ToString();
            textBoxTomatoDrought.Text = (tomato.GetCounter() / 2).ToString();
            textBoxPumpkin.Text = pumpkin.GetCounter().ToString();
            textBoxPumpkinDrought.Text = (pumpkin.GetCounter() / 2).ToString();
            textBoxFarmer.Text = farmer.GetCounter().ToString();
            textBoxFood.Text = farmer.GetFarmerPrice().ToString();
            if (clock.GetSeason() == 0)
            {
                textBoxSeason.Text = "Wiosna";
            }
            else if (clock.GetSeason() == 1)
            {
                textBoxSeason.Text = "Lato";
            }
            else if (clock.GetSeason() == 2)
            {
                textBoxSeason.Text = "Jesień";
            }
            else if (clock.GetSeason() == 3)
            {
                textBoxSeason.Text = "Zima";
            }
            drought.Decrement();
            newcomer.Decrement();
            blessing.Decrement();
            textBoxSeasonTime.Text = (120 - clock.GetCounter() % 120).ToString();
        }
        /// <summary>
        /// function saving game to file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonSave_Click(object sender, EventArgs e)
        {
            using (StreamWriter writer = new StreamWriter("savedGame.txt"))
            {
                writer.WriteLine(potato.GetCounter().ToString());
                writer.WriteLine(tomato.GetCounter().ToString());
                writer.WriteLine(pumpkin.GetCounter().ToString());
                writer.WriteLine(farmer.GetCounter().ToString());
                writer.WriteLine(farmer.GetFarmerPrice().ToString());
                writer.WriteLine(clock.GetCounter().ToString());
                writer.WriteLine(clock.GetSeason().ToString());
                writer.WriteLine(drought.GetTimeLeft().ToString());
                writer.WriteLine(blessing.GetTimeLeft().ToString());
                writer.WriteLine(blessing.GetBlessingTime().ToString());
                writer.WriteLine(newcomer.GetTimeLeft().ToString());
                MessageBox.Show("Zapisano!");
            }
        }
        /// <summary>
        /// function loading saved game from file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonLoad_Click(object sender, EventArgs e)
        {
            string line;
            using (StreamReader reader = new StreamReader("savedGame.txt"))
            {
                line = reader.ReadLine();
                potato.SetCounter(Int32.Parse(line));
                line = reader.ReadLine();
                tomato.SetCounter(Int32.Parse(line));
                line = reader.ReadLine();
                pumpkin.SetCounter(Int32.Parse(line));
                line = reader.ReadLine();
                farmer.SetCounter(Int32.Parse(line));
                line = reader.ReadLine();
                farmer.SetFarmerPrice(Int32.Parse(line));
                line = reader.ReadLine();
                clock.SetCounter(Int32.Parse(line));
                line = reader.ReadLine();
                clock.SetSeason(Int32.Parse(line));
                line = reader.ReadLine();
                drought.SetTimeLeft(Int32.Parse(line));
                line = reader.ReadLine();
                blessing.SetTimeLeft(Int32.Parse(line));
                line = reader.ReadLine();
                blessing.SetBlessingTime(Int32.Parse(line));
                line = reader.ReadLine();
                newcomer.SetTimeLeft(Int32.Parse(line));
                MessageBox.Show("Wczytano");
            }
        }
        /// <summary>
        /// function showing next element on the farmer list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonNext_Click(object sender, EventArgs e)
        {
            if (listIndex < 0)
            {
                listIndex += names.Count;
            }
            int index = Math.Abs(listIndex++ % names.Count);
            string name = names[index];
            textBoxName.Text = name;
            textBoxNumber.Text = index.ToString();
        }
        /// <summary>
        /// function showing previous element on the farmer list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonPrevious_Click(object sender, EventArgs e)
        {
            if (listIndex < 0)
            {
                listIndex += names.Count;
            }
            int index = Math.Abs(listIndex-- % names.Count);
            string name = names[index];
            textBoxName.Text = name;
            textBoxNumber.Text = index.ToString();
        }
    }
}
