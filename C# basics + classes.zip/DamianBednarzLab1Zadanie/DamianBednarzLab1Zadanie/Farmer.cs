﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamianBednarzLab1Zadanie
{
    class Farmer : Counter
    {
        private int farmerPrice;
        /// <summary>
        /// sets the starting price and number of farmers
        /// </summary>
        public Farmer()
        {
            farmerPrice = 40;
            counter = 2;
        }
        /// <summary>
        /// getter, gets number of farmers
        /// </summary>
        /// <returns></returns>
        public override int GetCounter()
        {
            return counter;
        }
        /// <summary>
        /// increases number of farmers
        /// </summary>
        public void Increment()
        {
            counter++;
        }
        /// <summary>
        /// setter, sets number of farmers
        /// </summary>
        /// <param name="counter"></param>
        public override void SetCounter(int counter)
        {
            this.counter = counter;
        }
        /// <summary>
        /// getter, gets price for 1 farmer
        /// </summary>
        /// <returns></returns>
        public int GetFarmerPrice()
        {
            return farmerPrice;
        }
        /// <summary>
        /// setter, sets price for farmer
        /// </summary>
        /// <param name="price"></param>
        public void SetFarmerPrice(int price)
        {
            farmerPrice = price;
        }
        /// <summary>
        /// function increases price at the end of year
        /// </summary>
        /// <param name="clock"></param>
        public void EndYear(Clock clock)
        {
            if (clock.GetCounter() % 480 == 0)
            {
                farmerPrice += 10;
            }
        }
        /// <summary>
        /// function which allows to buy a farmer, return true if bought
        /// </summary>
        /// <param name="potato"></param>
        /// <param name="tomato"></param>
        /// <param name="pumpkin"></param>
        /// <param name="clock"></param>
        /// <returns></returns>
        public bool Buy(Potato potato, Tomato tomato, Pumpkin pumpkin, Clock clock)
        {
            if (clock.GetSeason() == 0)
            {
                if (potato.GetCounter() >= farmerPrice)
                {
                    counter++;
                    potato.SetCounter(potato.GetCounter()-farmerPrice);
                    return true;
                }
            }
            else if (clock.GetSeason() == 1)
            {
                if (tomato.GetCounter() >= farmerPrice)
                {
                    counter++;
                    tomato.SetCounter(tomato.GetCounter() - farmerPrice);
                    return true;
                }
            }
            else if (clock.GetSeason() == 2)
            {
                if (pumpkin.GetCounter() >= farmerPrice)
                {
                    counter++;
                    pumpkin.SetCounter(pumpkin.GetCounter() - farmerPrice);
                    return true;
                }
            }
            return false;
        }
    }
}
