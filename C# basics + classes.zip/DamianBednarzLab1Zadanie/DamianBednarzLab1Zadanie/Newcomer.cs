﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DamianBednarzLab1Zadanie
{
    class Newcomer : Event
    {
        /// <summary>
        /// function sets time of first newcomer event
        /// </summary>
        public Newcomer()
        {
            timeLeft = rnd.Next(360) + 60;
        }
        /// <summary>
        /// decreases time till event
        /// </summary>
        public override void Decrement()
        {
            timeLeft--;
        }
        /// <summary>
        /// function which makes event happen, adds a farmer and sets new event if it isn't winter
        /// </summary>
        /// <param name="clock"></param>
        /// <param name="farmer"></param>
        /// <returns></returns>
        public bool EventHappen(Clock clock, Farmer farmer)
        {
            if ((timeLeft == 0) && (clock.GetSeason() != 3))
            {
                farmer.Increment();
                timeLeft = rnd.Next(330) + 30;
                MessageBox.Show("Farmer dołącza do kolonii");
                return true;
            }
            else if (timeLeft == 0)
            {
                timeLeft = rnd.Next(330) + 30;
            }
            return false;
        }
        /// <summary>
        /// getter, gets time left till event
        /// </summary>
        /// <returns></returns>
        public override int GetTimeLeft()
        {
            return timeLeft;
        }
        /// <summary>
        /// setter, sets time till event
        /// </summary>
        /// <param name="time"></param>
        public override void SetTimeLeft(int time)
        {
            this.timeLeft = time;
        }
    }
}
