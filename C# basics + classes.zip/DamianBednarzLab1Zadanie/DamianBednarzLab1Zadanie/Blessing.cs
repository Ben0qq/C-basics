﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DamianBednarzLab1Zadanie
{
    class Blessing : Event
    {
        private int blessingTime;
        /// <summary>
        /// cosntructor, sets starting time
        /// </summary>
        public Blessing()
        {
            timeLeft = rnd.Next(360) + 60;
            blessingTime = 0;
        }
        /// <summary>
        /// function that makes time flow
        /// </summary>
        public override void Decrement()
        {
            timeLeft--;
        }
        /// <summary>
        /// main function of the event, starts the blessing if it isn't winter
        /// </summary>
        /// <param name="clock"></param>
        public void EventHappen(Clock clock)
        {
            if ((timeLeft == 0) && (clock.GetSeason() != 3))
            {
                blessingTime = 60;
                timeLeft = rnd.Next(330) + 90;
                MessageBox.Show("Dobra pogoda zwiększa zbiory na 60s");
            }
            else if (timeLeft == 0)
            {
                timeLeft = rnd.Next(330) + 90;
            }
        }
        /// <summary>
        /// getter, returns time till event
        /// </summary>
        /// <returns></returns>
        public override int GetTimeLeft()
        {
            return timeLeft;
        }
        /// <summary>
        /// setter, sets time till event
        /// </summary>
        /// <param name="time"></param>
        public override void SetTimeLeft(int time)
        {
            this.timeLeft = time;
        }
        /// <summary>
        /// getter, gets remaining blessing time
        /// </summary>
        /// <returns></returns>
        public int GetBlessingTime()
        {
            return blessingTime;
        }
        /// <summary>
        /// setter, sets remaining blessing time
        /// </summary>
        /// <param name="time"></param>
        public void SetBlessingTime(int time)
        {
            blessingTime = time;
        }
    }
}
