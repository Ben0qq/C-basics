﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamianBednarzLab1Zadanie
{
    interface Vegetable
    {
        /// <summary>
        /// vegetable grow, depends on number of farmers and blessing event
        /// </summary>
        /// <param name="farmer"></param>
        /// <param name="blessing"></param>
        void Grow(Farmer farmer, Blessing blessing);
        /// <summary>
        /// function checks if its enough to feed farmers in current season
        /// </summary>
        /// <param name="farmer"></param>
        /// <returns></returns>
        bool isEnough(Farmer farmer);
    }
}
