﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamianBednarzLab1Zadanie
{
    public abstract class Counter
    {
        public int counter;
        /// <summary>
        /// getter zmiennej czasowej
        /// </summary>
        /// <returns></returns>
        public abstract int GetCounter();
        /// <summary>
        /// setter zmiennej czasowej
        /// </summary>
        /// <param name="counter"></param>
        public abstract void SetCounter(int counter);
    }
}
